import React from "react"

const Patient = () => {
    return(
        <>
            
        </>
    )
}

export default Patient;
import React, { Component } from "react";
import { render } from "@testing-library/react"
import DoctorHeader from "./DoctorHeader";

class DoctorProfile extends Component{
    render(){
        return(
            <div>
                
            </div>
        )
    }
        

}

export default DoctorProfile;
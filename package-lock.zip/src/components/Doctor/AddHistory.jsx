import React, { useEffect, useState } from "react"
import { Form, Button, Col, Row} from "react-bootstrap";
import DoctorService from "../../services/DoctorService";
import Swal from "sweetalert2";
import { useNavigate } from "react-router";

const AddHistory = () => {
    const navigate = useNavigate();
    const[patientIdfk, setPatientIdfk] = useState('');
    const[treatmentType, setTreatmentType] = useState('');
    const[medicine, setMedicine] = useState('');
    const[treatmentCost, setTreatmentCost] = useState('');
    const[treatmentDate, setTreatmentDate] = useState('');
    const pId = localStorage.getItem('pid');

    const handleSubmit =(e) => {
        e.preventDefault();
        const treatmentdetails = {patient:{patientId:pId}, treatmentType, medicine, treatmentCost, treatmentDate};
        DoctorService.addhistory(treatmentdetails)
        .then(response =>{
            Swal.fire({
                icon: 'success',
                title: 'Added!',
                text: `Details added Successful.`,
                showConfirmButton: false,
                timer: 3000
            });
            navigate('/ViewPatient');
            // localStorage.clear();
        })
        // .catch(error => {
        //     Swal.fire({
        //         icon: 'error',
        //         title: 'Oops!',
        //         text: `Details already available`,
        //         showConfirmButton: false,
        //         timer: 3000
        //     });
        //     console.log("error", error);
        // })
    }

    return(
        <>
            <Form onSubmit={handleSubmit}>
                <Row className="justify-content-md-center">
                <Col xs={12} md={6}>
                <h2>Add Patient Treatment Details</h2><br/>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>PatientId</Form.Label>
                    <Form.Control
                        type="number" 
                        placeholder="Enter PatientId"
                        disabled
                        value={pId}
                    />
                    {/* {errors.name && <p style={{color: 'red'}}>{errors.name}</p>} */}
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Enter Treatment Type</Form.Label>
                    <Form.Control 
                        type="text" 
                        placeholder="Enter Treatment type"
                        value={treatmentType}
                        onChange={(e) => setTreatmentType(e.target.value)} 
                    />
                    {/* {errors.name && <p style={{color: 'red'}}>{errors.name}</p>} */}
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Enter Medicine</Form.Label>
                    <Form.Control 
                        type="text" 
                        placeholder="Enter medicine"
                        value = {medicine}
                        onChange={(e) => setMedicine(e.target.value)}  
                    />
                    {/* {errors.mobile && <p style={{color: 'red'}}>{errors.mobile}</p>} */}
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Enter Treatment cost</Form.Label>
                    <Form.Control 
                        type="text" 
                        placeholder="Enter address"
                        value ={treatmentCost}
                        onChange={(e) => setTreatmentCost(e.target.value)} 
                    />
                    {/* {errors.address && <p style={{color: 'red'}}>{errors.address}</p>} */}
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Enter date of Treatment</Form.Label>
                    <Form.Control 
                        type="date"     
                        placeholder="Enter date of Treatment"
                        value={treatmentDate}
                        onChange={(e) => setTreatmentDate(e.target.value)}  
                    />
                    {/* {errors.dob && <p style={{color: 'red'}}>{errors.dob}</p>} */}
                </Form.Group>

                <Button variant="primary" type="submit">
                    Submit
                </Button>
                </Col>
                </Row>
            </Form>
        </>
    )
}

export default AddHistory;
import React, { useEffect, useState } from "react"
import { Card, ListGroup } from "react-bootstrap";
import DoctorService from "../../services/DoctorService";


const ViewTreatmentHistory = () => {
    const [history, setHistory] = useState([]);
    const pId = localStorage.getItem('pid');

    useEffect (() => {
        DoctorService.gethistorybypatientid(pId)
        .then(response =>{
            console.log("Displaying Treatments Details", response.data);
            setHistory(response.data);
            localStorage.clear();
        })
        .catch(error => {
            console.log('Treatment Details not found', error);
        })
    },[])

    return(
        <>
            {
                history && history.map(response => (
                    <Card style={{ width: '18rem' }} key={response.treatmentId}>
                        <Card.Header>Treatment Id : {response.treatmentId}</Card.Header>
                        <ListGroup variant="flush">
                            <ListGroup.Item>Treatment Type : {response.treatmentType}</ListGroup.Item>
                            <ListGroup.Item>Treatment Date: {response.treatmentDate}</ListGroup.Item>
                            <ListGroup.Item>Treatment Cost: {response.treatmentCost}</ListGroup.Item>
                            <ListGroup.Item>Medicine: {response.medicine}</ListGroup.Item>
                        </ListGroup>
                        <br/>
                    </Card>
                    
                ))
            }
        </>
        
    )
}

export default ViewTreatmentHistory;